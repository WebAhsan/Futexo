<?php get_header();?>

      <main>

         <!-- page__title-start -->
         <div class="page__title align-items-center">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="page__title-content text-center">
                        <h3 class="breadcrumb-title breadcrumb-title-sd mb-15"><?php the_title(); ?></h3>
                        <div class="page_title__bread-crumb">
                        <nav>
                           <nav class="breadcrumb-trail breadcrumbs">
                              <ul class="breadcrumb-menu">
                                 <li class="breadcrumb-trail">
                                    <a href="index.html"><span>Home</span></a>
                                 </li>
                                 <li class="trail-item">
                                    <span><?php the_title(); ?></span>
                                 </li>
                              </ul>
                           </nav> 
                        </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- page__title-end -->

         <!-- trainer_details_area-start -->
         <div class="trainer_details_area pt-120 pb-120">
            <div class="container custome-container">
               <div class="row align-items-center">
                  <div class="col-lg-6">
                     <div class="trainer_details_image mb-40">
                        <img src="<?php the_post_thumbnail_url();?>" alt="">
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="trainer_main_info mb-40">
                        <h4 class="trainer_dtitle"><?php the_title(); ?></h4>
                        <span class="trainer_d-degination mb-25"><?php the_field('trainer_dignation'); ?></span>
                        <p class="mb-30"><?php the_excerpt(); ?></p>
                        <div class="trainer_contact-info mb-40">

                           <ul>

                              <?php 
                              
                              $trainer_contact_infos = get_field('trainer_contact_info');
                              if($trainer_contact_infos){
                              foreach( $trainer_contact_infos as  $trainer_contact_info){
                              $contact_info_icon = $trainer_contact_info['contact_info_icon'];
                              $contact_info_text = $trainer_contact_info['contact_info_text'];
                              ?>
                              <li class="d-flex align-items-start mb-30">
                                 <div class="trainer_contact-icon mr-20">
                                    <?php echo $contact_info_icon; ?>
                                 </div>
                                 <div class="trainer_contact-text">
                                    <a href="tel:+012-345-6789"><?php echo  $contact_info_text ;?></a>
                                 </div>
                              </li>
                           <?php }} ?>
                           </ul>
                        </div>
                        <div class="trainer-social_icon">

                        <?php 
                              
                              $trainer_socials = get_field('trainer_social');
                              if($trainer_socials){
                              foreach( $trainer_socials as  $trainer_social){
                              $social_icon = $trainer_social['social_icon'];
                              $social_url = $trainer_social['social_url'];
                              ?>
                           <a href="<?php echo $social_url;?>"><?php echo $social_icon; ?></a>
                                 <?php } }?>

                        </div>
                     </div>
                  </div>
               </div>
               <h5 class="trainer_ds-title mb-15">Personal Summery</h5>
               <p class="mb-35"><?php the_content();?></p>
               <div class="row">
                  <div class="col-lg-6">
                     <h5 class="trainer_ds-title mb-15"><?php the_field('trainer_skill_title'); ?></h5>
                     <p class="mb-30"><?php the_field('trainer_skill_info'); ?></p>

                     <div class="tp-skill--content">

                     
                     <?php 
                              
                              $trainer_skills = get_field('trainer_skill');
                              if($trainer_skills){
                              foreach( $trainer_skills as  $trainer_skill){
                              $skill_name = $trainer_skill['skill_name'];
                              $skill_percentage = $trainer_skill['skill_percentage'];
                              ?>

                        <div class="tp-skill__wrapper tp-skill__wrapper-s mb-25 fix">
                            <div class="tp-skill--title__wrapper">
                                <h5 class="tp-skill--title"><?php echo $skill_name; ?></h5>
                            </div>
                            <div class="progress progress-two">
                              <div class="progress-bar progress-bar-two wow slideInLeft" data-wow-duration="1s" data-wow-delay=".3s" role="progressbar" data-width="<?php echo   $skill_percentage; ?>%" aria-valuenow="<?php echo   $skill_percentage; ?>" aria-valuemin="0" aria-valuemax="100"><span><?php echo   $skill_percentage; ?>%</span></div>
                           </div>
                        </div>
                        <?php }} ?>
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <h5 class="trainer_ds-title mb-20">Get In Touch</h5>
                     <div class="tp-trainer-form">
                        <div class="row">
                           <div class="col-md-12 custom-pad-20">
                                 <div class="tp-trainer-form-field mb-30">
                                    <textarea placeholder="Your Message"></textarea>
                                 </div>
                           </div>
                            <div class="col-md-6">
                                <div class="tp-trainer-form-field mb-30">
                                    <input type="text" placeholder="Full name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tp-trainer-form-field mb-35">
                                    <input type="email" placeholder="Email Address">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="tp-trainer-form-field">
                                    <button type="submit" class="tp-btn-trainer-round">Send Message <i class="fal fa-chevron-double-right"></i> </button>
                                </div>
                            </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- trainer_details_area-start -->
         
      </main>
      
<?php get_footer();?>