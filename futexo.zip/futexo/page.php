<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package futexo
 */

get_header();
?>
<div class="page__title align-items-center" >
            <div class="container">
                  <div class="row">
                     <div class="col-xl-12">
                        <div class="page__title-content text-center">
                           <h3 class="breadcrumb-title breadcrumb-title-sd mb-15"><?php the_title();?></h3>
                           <div class="page_title__bread-crumb">
                           <nav>
                              <nav class="breadcrumb-trail breadcrumbs">
                                 <ul class="breadcrumb-menu">
                                    <li class="breadcrumb-trail">
                                       <a href="<?php  home_url('/'); ?>"><span>Home</span></a>
                                    </li>
                                    <li class="trail-item">
                                       <span><?php the_title();?></span>
                                    </li>
                                 </ul>
                              </nav> 
                           </nav>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
<?php the_content();?>



<?php

get_footer();
