<?php 
/**
 * Register Post Type
 */

function futexo_custom_post_type() {
    register_post_type('futexo_slider',
        array(
            'labels'      => array(
                'name'          => __('Slider', 'futexo'),
                'singular_name' => __('Slider', 'futexo'),
				'add_new'               => __( 'Add New Slider', 'futexo' ),
				'add_new_item'          => __( 'Add New Slider', 'futexo' ),
				'new_item'              => __( 'New Slider', 'futexo' ),
				'edit_item'             => __( 'Edit Slider', 'futexo' ),
				'view_item'             => __( 'View Slider', 'futexo' ),
				'all_items'             => __( 'All Slider', 'futexo' ),
				'search_items'          => __( 'Search Slider', 'futexo' ),
				'featured_image'        => _x( 'Slider Image','futexo' ),
				'set_featured_image'    => _x( 'Add Slider Image','futexo' ),
				'remove_featured_image'    => _x( 'remove slider image','futexo' ),
            ),
                'public'      => true,
                'has_archive' => true,
				'menu_icon'	  => 'dashicons-slides',
 				
				'supports'   => array( 'title', 'editor', 'thumbnail', ),
        )
    );

	register_post_type( 'our_portfolio',
    // CPT Options
        array(
            'labels' => array(
				'name'          => __(' Fitness Portfolio', 'futexo'),
                'singular_name' => __(' Fitness Portfolio', 'futexo'),
				'add_new'               => __( 'Add New Portfolio', 'futexo' ),
				'add_new_item'          => __( 'Add New Portfolio', 'futexo' ),
				'new_item'              => __( 'New Portfolio', 'futexo' ),
				'edit_item'             => __( 'Edit Portfolio', 'futexo' ),
				'view_item'             => __( 'View Portfolio', 'futexo' ),
				'all_items'             => __( 'All Portfolio', 'futexo' ),
				'search_items'          => __( 'Search Portfolio', 'futexo' ),
				'featured_image'        => _x( 'Portfolio Image','futexo' ),
				'set_featured_image'    => _x( 'Add Portfolio Image','futexo' ),
				'remove_featured_image'    => _x( 'remove Portfolio image','futexo' ),
            ),
            'public' => true,
            'has_archive' => true,
			'menu_icon'	  => 'dashicons-portfolio',
			'supports'   => array( 'title', 'editor', 'thumbnail', ),
 
        )
    );
	register_post_type( 'fitness_schedule',
    // CPT Options
        array(
            'labels' => array(
				'name'          => __(' Fitness Schedule', 'futexo'),
                'singular_name' => __(' Fitness Schedule', 'futexo'),
				'add_new'               => __( 'Add New Schedule', 'futexo' ),
				'add_new_item'          => __( 'Add New Schedule', 'futexo' ),
				'new_item'              => __( 'New Schedule', 'futexo' ),
				'edit_item'             => __( 'Edit Schedule', 'futexo' ),
				'view_item'             => __( 'View Schedule', 'futexo' ),
				'all_items'             => __( 'All Schedule', 'futexo' ),
				'search_items'          => __( 'Search Schedule', 'futexo' ),
            ),
			'public'      => true,
			'has_archive' => true,
			'menu_icon'	  => 'dashicons-schedule',
			'supports'   => array( 'title'),
		
 
        )
    );
	register_post_type( 'fitness_trainer',
    // CPT Options
        array(
            'labels' => array(
				'name'          => __(' Fitness Trainer', 'futexo'),
                'singular_name' => __(' Fitness Trainer', 'futexo'),
				'add_new'               => __( 'Add New Trainer', 'futexo' ),
				'add_new_item'          => __( 'Add New Trainer', 'futexo' ),
				'new_item'              => __( 'New Trainer', 'futexo' ),
				'edit_item'             => __( 'Edit Trainer', 'futexo' ),
				'view_item'             => __( 'View Trainer', 'futexo' ),
				'all_items'             => __( 'All Trainer', 'futexo' ),
				'search_items'          => __( 'Search Trainer', 'futexo' ),
				
            ),
			'public'      => true,
			'menu_icon'	  => 'dashicons-groups',
			'supports'   => array( 'title','editor','thumbnail','excerpt'),
		
 
        )
    );
	register_post_type( 'our_classes',
    // CPT Options
        array(
            'labels' => array(
				'name'          => __(' Fitness Classes', 'futexo'),
                'singular_name' => __(' Fitness Classes', 'futexo'),
				'add_new'               => __( 'Add New Classes', 'futexo' ),
				'add_new_item'          => __( 'Add New Classes', 'futexo' ),
				'new_item'              => __( 'New Classes', 'futexo' ),
				'edit_item'             => __( 'Edit Classes', 'futexo' ),
				'view_item'             => __( 'View Classes', 'futexo' ),
				'all_items'             => __( 'All Classes', 'futexo' ),
				'search_items'          => __( 'Search Classes', 'futexo' ),
				
            ),
			'public'      => true,
			'has_archive' => true,
			'menu_icon'	  => 'dashicons-screenoptions',
			'supports'   => array( 'title','editor','thumbnail'),
		
 
        )
    );

}
add_action('init', 'futexo_custom_post_type');

function schedule_date() {
    register_taxonomy( 'schedule_date', 'fitness_schedule', array(
        'label'        => __( 'Schedule Date', 'futexo' ),
        'hierarchical' => true,
    ) );
	register_taxonomy( 'classes_category', 'our_classes', array(
        'label'        => __( 'Classes Category', 'futexo' ),
        'hierarchical' => true,
    ) );
	register_taxonomy( 'portfolio_category', 'our_portfolio', array(
        'label'        => __( 'Portfolio Category', 'futexo' ),
        'hierarchical' => true,
    ) );
}
add_action( 'init', 'schedule_date', 0 );