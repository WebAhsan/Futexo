<?php 


require_once get_template_directory(). '/inc/class-tgm-plugin-activation.php';


function futexo_plugin_activatin(){

    $plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Elementor Website Builder', // The plugin name.
			'slug'               => 'elementor', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
		array(
			'name'               => 'Kirki Customizer Framework', // The plugin name.
			'slug'               => 'kirki', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
		array(
			'name'               => 'Advanced Custom Fields', // The plugin name.
			'slug'               => 'advanced-custom-fields', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'Cf7 Icons and Labels', // The plugin name.
			'slug'               => 'cf7-icons-and-labels', // The plugin slug (typically the folder name).
			'required'           => false, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'Contact Form 7', // The plugin name.
			'slug'               => 'contact-form-7', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
        array(
			'name'               => 'One Click Demo Import', // The plugin name.
			'slug'               => 'one-click-demo-import', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
		
        array(
			'name'               => 'Advanced Custom Fields: Font Awesome Field', // The plugin name.
			'slug'               => 'advanced-custom-fields-font-awesome', // The plugin slug (typically the folder name). 
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),

		
		
		// <snip />
	);
    $config = array(
        'id'           => 'futexo_plugin_activation',                 // Unique ID for hashing notices for multiple instances of TGMPA.                 // Default absolute path to bundled plugins.
        'menu'         => 'futexo-plugin-activation', // Menu slug.
        'parent_slug'  => 'themes.php',            // Parent menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
    );




    tgmpa( $plugins, $config );

   

}

add_action( 'tgmpa_register', 'futexo_plugin_activatin' );



