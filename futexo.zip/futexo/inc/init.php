<?php
/**
 * Enqueue scripts and styles.
 */
function futexo_scripts() {
	wp_enqueue_style( 'futexo-style', get_stylesheet_uri(), array(), _S_VERSION );
	
	wp_enqueue_style( 'preloader-css', get_template_directory_uri() .'/assets/css/preloader.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'bootstrap-css', get_template_directory_uri() .'/assets/css/bootstrap.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'meanmenu-css', get_template_directory_uri() .'/assets/css/meanmenu.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'animate-css', get_template_directory_uri() .'/assets/css/animate.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'carousel-css', get_template_directory_uri() .'/assets/css/owl.carousel.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'swiper-bundle-css', get_template_directory_uri() .'/assets/css/swiper-bundle.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'backToTop-css', get_template_directory_uri() .'/assets/css/backToTop.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'magnific-popup-css', get_template_directory_uri() .'/assets/css/magnific-popup.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'nice-select-css', get_template_directory_uri() .'/assets/css/nice-select.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'fontAwesome5Pro-css', get_template_directory_uri() .'/assets/css/fontAwesome5Pro.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'flaticon-css', get_template_directory_uri() .'/assets/flatiocn/flaticon.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'default-css', get_template_directory_uri() .'/assets/css/default.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'main-css', get_template_directory_uri() .'/assets/css/main.css', array(), '1.0.0', 'all' );
	

	wp_style_add_data( 'futexo-style', 'rtl', 'replace' );

	wp_enqueue_script( 'jquery-js', get_template_directory_uri() . '/assets/js/vendor/jquery-3.6.0.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'jquery-js', get_template_directory_uri() . '/assets/js/vendor/waypoints.min.js.js', array(), '1.0.0', true );
	wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'meanmenu-js', get_template_directory_uri() . '/assets/js/meanmenu.js', array(), '1.0.0', true );
	wp_enqueue_script( 'swiper-bundle-js', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'carousel-js', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'magnific-popup-js', get_template_directory_uri() . '/assets/js/magnific-popup.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'parallax-js', get_template_directory_uri() . '/assets/js/parallax.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'backToTop-js', get_template_directory_uri() . '/assets/js/backToTop.js', array(), '1.0.0', true );
	wp_enqueue_script( 'nice-select-js', get_template_directory_uri() . '/assets/js/nice-select.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'counterup-js', get_template_directory_uri() . '/assets/js/counterup.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'ajax-form-js', get_template_directory_uri() . '/assets/js/ajax-form.js', array(), '1.0.0', true );
	wp_enqueue_script( 'wow-js', get_template_directory_uri() . '/assets/js/wow.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'isotope-js', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'imagesloaded-js', get_template_directory_uri() . '/assets/js/imagesloaded.pkgd.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'main-js', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true );

	


	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'futexo_scripts' );
