<?php

// Category Widget
class futexo_footer_about_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'futexo_footer_about_Widget',
			'description' => 'Add futexo footer About',
		);
		parent::__construct( 'futexo_footer_about_Widget', 'About Futexo', $widget_ops );

	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		echo $args['before_title'];
		echo $instance['title'];
		echo $args['after_title'];
		echo $args['after_widget'];

		$widget_id = 'widget_'. $args['widget_id'];

		$about_des = get_field('about_des',$widget_id);
		$about_socials = get_field('about_social',$widget_id);
		$about_image = get_field('about_image',$widget_id);


		?>

            <div class="footer-logo mb-25">
                              <a href="index.html"><img src="<?php echo $about_image['url']?>" alt=""></a>
                           </div>
                           <p class="pb-30"><?php echo $about_des;  ?></p>
                           <div class="footer-social">

					<?php 
					
					foreach($about_socials as $about_social){	
					?>
					<a href="<?php echo $about_social['socail_url']; ?>"><i class="<?php echo $about_social['social_icon']; ?>"></i></a>
					<?php } ?>

	</div>
	
			<?php 	}	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
		public function form( $instance )     {
			$title = !empty($instance["title"])
				? $instance["title"]
				: esc_html__("", "startup"); ?>
			<p>
			<label for="<?php echo esc_attr(
				$this->get_field_id("title")
			); ?>"><?php echo esc_html__("Title:", "startup"); ?></label>
				<input class="widefat" id="<?php echo esc_attr(
					$this->get_field_id("title")
				); ?>" name="<?php echo esc_attr($this->get_field_name("title")); ?>" type="text" value="<?php echo esc_attr($title); ?>">
			</p>
			<?php
		}

/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance )     {
        $instance = [];

        $instance["title"] = !empty($new_instance["title"])
            ? strip_tags($new_instance["title"])
            : "";
        $instance["order_by"] = !empty($new_instance["order_by"])
            ? strip_tags($new_instance["order_by"])
            : "";

        return $instance;
    }

		}
add_action( 'widgets_init', function(){
	register_widget( 'futexo_footer_about_Widget' );
});


