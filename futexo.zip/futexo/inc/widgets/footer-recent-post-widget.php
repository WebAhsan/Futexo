<?php


// Category Widget
class futexo_footer_recent__post_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'futexo_footer_recent__post_Widget',
			'description' => 'Add futexo footer About',
		);
		parent::__construct( 'futexo_footer_recent__post_Widget', 'Footer Recent Post Futexo', $widget_ops );

	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		echo $args['before_title'];
		echo $instance['title'];
		echo $args['after_title'];
		echo $args['after_widget'];

		$args = array(
            'post_type' => 'post',
            'posts_per_page' => 2,
        );
        $footer_rp_query = new WP_Query($args);
    
		?>

<ul>

                <?php 
                
                while($footer_rp_query->have_posts()): $footer_rp_query->the_post();
                
                ?>
                                 <li class="mb-25 pt-5">
                                    <div class="footer__blog-sm d-flex align-items-center">
                                       <div class="footer__blog-sm-thumb mr-25">
                                          <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail(); ?>
                                          </a>
                                       </div>
                                       <div class="footer__blog-sm-content">
                                          <h6 class="footer__blog-sm-title">
                                             <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                          </h6>
                                          <div class="footer__blog-sm-meta">
                                             <p><span><?php echo get_the_date('j M Y'); ?></span></p>
                                          </div>
                                       </div>
                                    </div>
                                 </li>

            <?php 

    endwhile;
            
            ?>

                              </ul>

	





			<?php 	}	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
		public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'futexo' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'futexo' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
	
		<?php 
	}

/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		
		return $instance;
	}

		}
add_action( 'widgets_init', function(){
	register_widget( 'futexo_footer_recent__post_Widget' );
});


