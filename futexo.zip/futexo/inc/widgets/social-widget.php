<?php
// Category Widget
class futexo_social_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'futexo_social_Widget',
			'description' => 'Add futexo footer About',
		);
		parent::__construct( 'futexo_social_Widget', 'Social Futexo', $widget_ops );

	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$widget_id = 'widget_'. $args['widget_id'];
		$socials = get_field('futexo_top_bar_social_',$widget_id);
		?>

<div class="sidebar__social">
		<ul>
			<?php 

			foreach($socials as $social){
			?>
			<li><a href="<?php echo  $social['social_url'];?>"><?php echo  $social['social_icon'];?></a></li>
			<?php } ?>
		</ul>
</div>
	
			<?php echo $args['after_widget']; 	} 
				/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
		public function form( $instance ) {
	}

/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		
		return $instance;
	}


		}
add_action( 'widgets_init', function(){
	register_widget( 'futexo_social_Widget' );
});


