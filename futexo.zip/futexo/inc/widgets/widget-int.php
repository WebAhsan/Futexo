<?php

/**
 * Tags Widget
 */
require get_template_directory() . '/inc/widgets/tags-widget.php';

/**
 * Subscriptions Widget
 */
require get_template_directory() . '/inc/widgets/subscription-widget.php';
/**
 * Search Widget
 */
require get_template_directory() . '/inc/widgets/search-widget.php';
/**
 * Recent Post Widget
 */
require get_template_directory() . '/inc/widgets/recent-post-widget.php';
/**
 * Category Widget
 */
require get_template_directory() . '/inc/widgets/category-widget.php';
/**
 * Category Widget
 */
require get_template_directory() . '/inc/widgets/gallery-widget.php';
/**
 * About Widget
 */
require get_template_directory() . '/inc/widgets/about-widget.php';
/**
 * About Widget
 */
require get_template_directory() . '/inc/widgets/contact-widget.php';
/**
 * About Widget
 */
require get_template_directory() . '/inc/widgets/footer-recent-post-widget.php';
/**
 * Top Contact Info Widget
 */
require get_template_directory() . '/inc/widgets/top-sidebar-contact-widget.php';
/**
 * Top Contact Info Widget
 */
require get_template_directory() . '/inc/widgets/social-widget.php';




