<?php

// Category Widget
class futexo_category_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'futexo_category_Widget',
			'description' => 'Add futexo category',
		);
		parent::__construct( 'futexo_category_Widget', 'Futexo Category', $widget_ops );

	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		echo $args['before_title'];
		echo $instance['title'];
		echo $args['after_title'];
		echo $args['after_widget'];

		$arg = array(
			'taxonomy' => 'category',
			'posts_per_page' => 5,
			'orderby' => 'name',
			'order'   => 'ASC'
		);

$cats = get_categories($arg);
?>
<ul class="product-catagory_list mb-30">
<?php

foreach($cats as $cat)

		{?>
			<li>		
			<a href="<?php echo get_category_link( $cat->term_id );  ?>"><?php echo $cat->name;  ?></a>
			<?php	
			if($instance['number'] == true): ?>
			<a href="<?php echo get_category_link( $cat->term_id );  ?>">(<?php echo $cat->count;  ?>)</a>
			<?php endif; ?>
			</li>
			
		<?Php

		}
		?>
				</ul>
		<?php

			}

				/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
		public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'futexo' );
		$chkd = ! empty( $instance['chkd'] ) ? $instance['chkd'] : esc_html__( 'Show Post Number', 'futexo' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'futexo' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('chkd'); ?>" name="<?php echo $this->get_field_name('chkd'); ?>"<?php checked( $chkd ); ?> />
        <label for="<?php echo $this->get_field_id('chkd'); ?>"><?php _e( 'Show post number' ); ?></label>
		</p>
	
		<?php 
	}

/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['number'] = ( ! empty( $new_instance['number'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		
		return $instance;
	}

		}
add_action( 'widgets_init', function(){
	register_widget( 'futexo_category_Widget' );
});


