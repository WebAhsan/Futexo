<?php

// Recent Post Widget
class futexo_recentpost_Widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'futexo_recentpost_Widget',
			'description' => 'My Widget is awesome',
		);
		parent::__construct( 'my_widget', 'Futexo Recent Post', $widget_ops );
	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		echo $args['before_title'];
		echo $instance['title'];
		echo $args['after_title'];
		echo $args['after_widget'];
		$arg = array(
			'post_type' => 'post',
			'posts_per_page' => $instance['post_number'],
			'orderby' => 'name',
			'order'   => 'ASC'
		);

$recent_query = new WP_Query($arg);

while($recent_query->have_posts()) : $recent_query->the_post();
	?>

<div class="sidebar_post mb-30">
<div class="post-image">
	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?><a>
</div>
<span class="small-post_date mb-10"><?php echo get_the_date('j F - Y'); ?></span>
<h6 class="small-post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
</div>



<?php

endwhile;
	}



					/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'New title', 'futexo' );
		$post_number = ! empty( $instance['post_number'] ) ? $instance['post_number'] : esc_html__( 'Post Number', 'futexo' );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'futexo' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'post_number' ) ); ?>"><?php esc_attr_e( 'Post Number:', 'futexo' ); ?></label> 
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post_number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_number' ) ); ?>" type="text" value="<?php echo esc_attr( $post_number ); ?>">
		</p>

	
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['post_number'] = ( ! empty( $new_instance['post_number'] ) ) ? strip_tags( $new_instance['post_number'] ) : '';
		
		return $instance;
	}


}
add_action( 'widgets_init', function(){
	register_widget( 'futexo_recentpost_Widget' );
});
