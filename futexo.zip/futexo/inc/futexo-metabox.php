<?php
add_action( 'cmb2_admin_init', 'fuetxo_custom_field' );
/**
 * Define the metabox and field configurations.
 */
function fuetxo_custom_field() {

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'related_post_metabox',
		'title'         => __( 'Test Metabox', 'cmb2' ),
		'object_types'  => array( 'post', ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
	) );

	// Regular text field
	$cmb->add_field( array(
		'name'             => 'Related Posts',
		'desc'             => 'Select an option',
		'id'               => 'futexo_related_post',
		'type'             => 'select',
		'show_option_none' => false,
		'default'          => 'on',
		'options'          => array(
			'off' => __( 'Off', 'fuetxo' ),
			'on'   => __( 'On', 'fuetxo' ),
		),
	) );

	$cmb->add_field( array(
		'name'             => 'Related Post Type',
		'desc'             => 'Select an option',
		'id'               => 'futexo_related_post_type',
		'type'             => 'select',
		'show_option_none' => false,
		'default'          => 'Category',
		'options'          => array(
			'Category' => __( 'Category', 'fuetxo' ),
			'Date'   => __( 'Date', 'fuetxo' ),
		),
	) );
	
	// Add other metaboxes as needed
	
	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'futexo_slider_metarials',
		'title'         => __( 'Slider Options', 'futexo' ),
		'object_types'  => array( 'futexo_slider', ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
	) );
	// Slider Subtitle text field
	$cmb->add_field( array(
		'name'             => __('Add Slider Subtitle','futexo'),
		'desc'             => __('Subtitle for your slider','futexo'),	
		'id'               => 'futexo_slider_subtitle',
		'type'    		   => 'text',
		'default'          => 'Fitness Zone',
	) );
	// Slider Button text field
	$cmb->add_field( array(
		'name'             => __('Add Slider Button','futexo'),
		'desc'             => __('Button for your slider','futexo'),
		'id'               => 'futexo_slider_btn_text',
		'type'    		   => 'text',
		'default'          => 'explore More',
	) );
	// Slider Button text field
	$cmb->add_field( array(
		'name'             => __('Add Slider Button Link','futexo'),
		'desc'             => __('Link for your Button ','futexo'),
		'id'               => 'futexo_slider_btn_link',
		'type'    		   => 'text_url',
		 'protocols' => array( 'http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet' ), // Array of allowed protoco
		'default'          => '#',
	) );
	// Slider Button text field
	$cmb->add_field( array(
		'name'             => __('Add Slider Video','futexo'),
		'desc'             => __('Video for your Slider ','futexo'),
		'id'               => 'futexo_slider_video_link',
		'type'    		   => 'oembed',
		'default'          => 'https://www.youtube.com/watch?v=ZoZSp-wy8h8',
	) );

	$group_field_id = $cmb->add_field( array(
		'id'          => 'slider_socials',
		'type'        => 'group',
		'description' => __( 'Slider Socials', 'futexo' ),
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'       => __( 'Add Social', 'futexo' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => __( 'Add Another', 'futexo' ),
			'remove_button'     => __( 'Remove', 'futexo' ),
			'sortable'          => true,
			// 'closed'         => true, // true to have the groups closed by default
			// 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
		),
	) );

	
	$cmb = new_cmb2_box( array(
		'id'            => 'fitness_gallery_metabox',
		'title'         => __( ' Customer Info', 'cmb2' ),
		'object_types'  => array( 'fitness_gallery', ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
	) );
	$cmb->add_field( array(
		'name'             => __('Add Service Name','futexo'),
		'desc'             => __('Service Name ','futexo'),
		'id'               => 'fitness_service_name',
		'type'    		   => 'text',
		'default'          => 'Fitness Workout',
	) );
	$cmb->add_field( array(
		'name'             => __('Add Category','futexo'),
		'desc'             => __('Categories ','futexo'),
		'id'               => 'fitness_category_name',
		'type'    		   => 'text',
		'default'          => 'Body Building',
	) );
	$cmb->add_field( array(
		'name'             => __('Add Client Name','futexo'),
		'desc'             => __('Client Name ','futexo'),
		'id'               => 'fitness_client_name',
		'type'    		   => 'text',
		'default'          => 'Fiter jack',
	) );
	$cmb->add_field( array(
		'name'             => __('Add Date','futexo'),
		'desc'             => __('date ','futexo'),
		'id'               => 'fitness_date',
		'type'    		   => 'text_date',
		'default'          => '12 April - 2021',
	) );
	$cmb->add_field( array(
		'name'             => __('Add Feedback','futexo'),
		'desc'             => __('Feedback ','futexo'),
		'id'               => 'fitness_feedback',
		'type'    		   => 'textarea',
		'default'          => 'Happy client',
	) );
	$cmb->add_field( array(
		'name'             => __('Add Client Image','futexo'),
		'desc'             => __('Client Image ','futexo'),
		'id'               => 'fitness_client_image',
		'type'    => 'file',
    // Optional:
    'options' => array(
        'url' => false, // Hide the text input for the url
    ),
	// query_args are passed to wp.media's library query.
    'query_args' => array(
        'type' => 'application/pdf', // Make library only display PDFs.
        // Or only allow gif, jpg, or png images
        // 'type' => array(
        //     'image/gif',
        //     'image/jpeg',
        //     'image/png',
        // ),
    ),
	
	) );
	
	$cmb = new_cmb2_box( array(
		'id'            => 'schedule_date_metabox',
		'title'         => __( ' Customer Info', 'cmb2' ),
		'object_types'  => array( 'term', ), // Post type
		'taxonomies'       => array( 'schedule_date' ),
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
	) );
	$cmb->add_field( array(
			'name' => 'Test Time Picker',
			'id' => 'wiki_test_texttime',
			'type' => 'text_time'
			// Override default time-picker attributes:
			// 'attributes' => array(
			//     'data-timepicker' => json_encode( array(
			//         'timeOnlyTitle' => __( 'Choose your Time', 'cmb2' ),
			//         'timeFormat' => 'HH:mm',
			//         'stepMinute' => 1, // 1 minute increments instead of the default 5
			//     ) ),
			// ),
			// 'time_format' => 'h:i:s A',
		) );
		$cmb = new_cmb2_box( array(
			'id'            => 'schedule_metabox',
			'title'         => __( ' Customer Info', 'cmb2' ),
			'object_types'  => array( 'fitness_schedule', ), // Post type
			'context'       => 'normal',
			'priority'      => 'high',
			'show_names'    => true, // Show field names on the left
			// 'cmb_styles' => false, // false to disable the CMB stylesheet
			// 'closed'     => true, // Keep the metabox closed by default
		) );
		$cmb->add_field( array(
				'name' => 'Test Time Picker',
				'id' => 'wiki_test_texttime',
				'type' => 'text_time'
				// Override default time-picker attributes:
				// 'attributes' => array(
				//     'data-timepicker' => json_encode( array(
				//         'timeOnlyTitle' => __( 'Choose your Time', 'cmb2' ),
				//         'timeFormat' => 'HH:mm',
				//         'stepMinute' => 1, // 1 minute increments instead of the default 5
				//     ) ),
				// ),
				// 'time_format' => 'h:i:s A',
			) );
			$cmb = new_cmb2_box( array(
				'id'            => 'fitness_trainer',
				'title'         => __( ' Customer Info', 'cmb2' ),
				'object_types'  => array( 'fitness_schedule', ), // Post type
				'context'       => 'normal',
				'priority'      => 'high',
				'show_names'    => true, // Show field names on the left
				// 'cmb_styles' => false, // false to disable the CMB stylesheet
				// 'closed'     => true, // Keep the metabox closed by default
			) );
			$group_field_id = $cmb->add_field( array(
				'id'          => 'trainer_contact_info',
				'type'        => 'group',
				'description' => __( 'Generates reusable form entries', 'cmb2' ),
				// 'repeatable'  => false, // use false if you want non-repeatable group
				'options'     => array(
					'group_title'       => __( 'Entry {#}', 'cmb2' ), // since version 1.1.4, {#} gets replaced by row number
					'add_button'        => __( 'Add Another Entry', 'cmb2' ),
					'remove_button'     => __( 'Remove Entry', 'cmb2' ),
					'sortable'          => true,
					// 'closed'         => true, // true to have the groups closed by default
					// 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
				),
			) );

			
}
