<?php 

if(class_exists('kirki')){
Kirki::add_config( 'futexo_config', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );

Kirki::add_panel( 'futexo_panel', array(
    'priority'    => 10,
    'title'       => esc_html__( 'Futexo Options', 'futexo' ),
    'description' => esc_html__( 'Description', 'futexo' ),
) );

Kirki::add_section( 'futexo_header_top_option', array(
    'title'          => esc_html__( 'Header Top', 'futexo' ),
    'description'    => esc_html__( 'Customize header top area.', 'futexo' ),
    'panel'          => 'futexo_panel',
    'priority'       => 160,
) );


Kirki::add_field( 'futexo_config', [
	'type'        => 'custom',
	'settings'    => 'header_top_content_setting',
	'section'     => 'futexo_header_top_option',
	'default'         => '<h3 style="padding:15px 10px; background:#fff; margin:0;">' . __( 'Header Top Content', 'futexo' ) . '</h3>',
	'priority'    => 10,
] );

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'header_top_switcher',
		'label'       => esc_html__( 'Show header top sections', 'futexo' ),
		'section'     => 'futexo_header_top_option',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'Show', 'futexov' ),
			'off' => esc_html__( 'Hide', 'futexo' ),
		],
	]
);

new \Kirki\Field\Repeater(
	[
		'settings' => 'header_top_repeater',
		'label'    => esc_html__( 'Contact Items', 'futexo' ),
		'section'  => 'futexo_header_top_option',
		'priority' => 10,
		'row_label'    => [
			'type'  => 'field',
			'value' => esc_html__( 'Item', 'kirki' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__( 'Add new item', 'kirki' ),
		'default'  => [
			[
				'contact_item_icon'   => esc_html__( 'flaticon-pin', 'futexo' ),
				'contact_item_title'    => 'Our Location',
				'contact_item_des' => '25/7 Barden, London',
			],
			[
				'contact_item_icon'   => esc_html__( 'flaticon-email', 'futexo' ),
				'contact_item_title'    => 'Online Support',
				'contact_item_des' => 'info@fetoxe2.coms',
			],
			[
				'contact_item_icon'   => esc_html__( 'flaticon-contact', 'futexo' ),
				'contact_item_title'    => 'Free Contact',
				'contact_item_des' => '02-325-562-3652',
			],

		],

		'fields'   => [
			'contact_item_icon' => [
				'type'        => 'select',
				'label'       => esc_html__( 'Icon', 'futexo' ),
				'default'     => 'Pin',
				'choices'     => [
					'flaticon-pin' => esc_html__( 'Pin', 'futexo' ),
					'flaticon-email'  => esc_html__( 'Email', 'futexo' ),
					'flaticon-contact'  => esc_html__( 'Contact', 'futexo' ),
				],
			],

			'contact_item_title'   => [
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'futexo' ),
				'default'     => 'Our Location',
			],
			'contact_item_des'    => [
				'type'        => 'text',
				'label'       => esc_html__( 'Info', 'kirki' ),
				'default'     => '25/7 Barden, London',
			],
		],
	]
);

Kirki::add_section( 'futexo_header_option', array(
    'title'          => esc_html__( 'Header', 'futexo' ),
    'description'    => esc_html__( 'Customize header area.', 'futexo' ),
    'panel'          => 'futexo_panel',
    'priority'       => 160,
) );


Kirki::add_field( 'futexo_config', [
	'type'        => 'custom',
	'settings'    => 'header_content_setting',
	'section'     => 'futexo_header_option',
	'default'         => '<h3 style="padding:15px 10px; background:#fff; margin:0;">' . __( 'Header Content', 'futexo' ) . '</h3>',
	'priority'    => 10,
] );

new \Kirki\Field\Text(
	[
		'settings' => 'header_contact_text',
		'label'    => esc_html__( 'Button Text', 'futexo' ),
		'section'  => 'futexo_header_option',
		'default'  => esc_html__( 'Contact Us', 'futexo' ),
		'priority' => 10,
	]
);
new \Kirki\Field\URL(
	[
		'settings' => 'header_contact_link',
		'label'    => esc_html__( 'Button Link', 'futexo' ),
		'section'  => 'futexo_header_option',
		'default'  => 'http://practise.test/contact/',
		'priority' => 10,
	]
);

new \Kirki\Field\Radio_Buttonset(
	[
		'settings'    => 'header_width_btnset',
		'label'       => esc_html__( 'Header Widht', 'futexo' ),
		'section'     => 'futexo_header_option',
		'default'     => 'container',
		'priority'    => 10,
		'choices'     => [
			'container-fluid'   => esc_html__( 'Full width', 'futexo' ),
			'container'   => esc_html__( 'Boxed', 'futexo' ),

		],
	]
);
new \Kirki\Field\Radio_Buttonset(
	[
		'settings'    => 'c',
		'label'       => esc_html__( 'Header Position', 'futexo' ),
		'section'     => 'futexo_header_option',
		'default'     => 'header-sticky',
		'priority'    => 10,
		'choices'     => [
			'header-nonsticky'   => esc_html__( 'Fixed', 'futexo' ),
			'header-sticky'   => esc_html__( 'Sticky', 'futexo' ),

		],
	]
);

new \Kirki\Field\Radio_Buttonset(
	[
		'settings'    => 'backto_top_btnset',
		'label'       => esc_html__( 'Header Position', 'futexo' ),
		'section'     => 'futexo_header_option',
		'default'     => '90',
		'priority'    => 10,
		'choices'     => [
			'90'   => esc_html__( 'Right', 'futexo' ),
			'10'   => esc_html__( 'Left', 'futexo' ),

		],
	]
);


new \Kirki\Field\Color(
	[
		'settings'    => 'header_menu_clr',
		'label'       => __( 'Menu Background', 'futexo' ),
		'section'     => 'futexo_header_option',
		'default'     => '#ffffff38',
	]
);
new \Kirki\Field\Color(
	[
		'settings'    => 'header_sticky_clr',
		'label'       => __( 'Sticky Background', 'futexo' ),
		'section'     => 'futexo_header_option',
		'default'     => '#152136',
	]
);
new \Kirki\Field\Color(
	[
		'settings'    => 'header_menu_item_clr',
		'label'       => __( 'Menu Color', 'futexo' ),
		'section'     => 'futexo_header_option',
		'default'     => '#fff',
	]
);


// Footer Options

Kirki::add_section( 'futexo_footer_option', array(
    'title'          => esc_html__( 'Footer ', 'futexo' ),
    'description'    => esc_html__( 'Customize footer bottom area.', 'futexo' ),
    'panel'          => 'futexo_panel',
    'priority'       => 160,
) );


Kirki::add_field( 'futexo_config', [
	'type'        => 'custom',
	'settings'    => 'header_content_setting',
	'section'     => 'futexo_footer_option',
	'default'         => '<h3 style="padding:15px 10px; background:#fff; margin:0;">' . __( 'Footer Content', 'futexo' ) . '</h3>',
	'priority'    => 10,
] );


new \Kirki\Field\Background(
	[
		'settings'    => 'footer_background_setting',
		'label'       => esc_html__( 'Footer Background', 'futexo' ),
		'section'     => 'futexo_footer_option',
		'default'     => [
			'background-color'      => '#000',
			'background-image'      => '',
			'background-repeat'     => 'no-repeat',
			'background-position'   => 'center center',
			'background-size'       => 'cover',
			'background-attachment' => 'scroll',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.footer-area',
			],
		],
	]
);
new \Kirki\Field\Code(
	[
		'settings'    => 'footer_coopyright_setting',
		'label'       => esc_html__( 'Copyright', 'futexo' ),
		'section'     => 'futexo_footer_option',
		'default'     => '',
		'choices'     => [
			'language' => 'html',
		],
	]
);
new \Kirki\Field\Code(
	[
		'settings'    => 'footer_coopyright_link',
		'label'       => esc_html__( 'Copyright useful link', 'futexo' ),
		'section'     => 'futexo_footer_option',
		'default'     => '',
		'choices'     => [
			'language' => 'html',
		],
	]
);


// Breadcrumb Options

Kirki::add_section( 'futexo_Breadcrumb_option', array(
    'title'          => esc_html__( 'Breadcrumb ', 'futexo' ),
    'description'    => esc_html__( 'Customize breadcrumb  area.', 'futexo' ),
    'panel'          => 'futexo_panel',
    'priority'       => 160,
) );


Kirki::add_field( 'futexo_config', [
	'type'        => 'custom',
	'settings'    => 'futexo_content_setting',
	'section'     => 'futexo_Breadcrumb_option',
	'default'         => '<h3 style="padding:15px 10px; background:#fff; margin:0;">' . __( 'Breadcrumb Content', 'futexo' ) . '</h3>',
	'priority'    => 10,
] );


new \Kirki\Field\Background(
	[
		'settings'    => 'breadcrumb_background_setting',
		'label'       => esc_html__( 'Footer Background', 'futexo' ),
		'section'     => 'futexo_Breadcrumb_option',
		'default'     => [
			'background-color'      => '#000',
			'background-image'      => '',
			'background-repeat'     => 'no-repeat',
			'background-position'   => 'center center',
			'background-size'       => 'cover',
			'background-attachment' => 'scroll',
		],
		'transport'   => 'auto',
		'output'      => [
			[
				'element' => '.page__title',
			],
		],
	]
);


}