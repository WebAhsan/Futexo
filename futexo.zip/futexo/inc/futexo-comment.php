<?php
/**
 * Custom comment walker for this theme
 */
class futexo_Walker_Comment extends Walker_Comment {

	/**
	 * Outputs a comment in the HTML5 format.
	 *
	 * @see wp_list_comments()
	 *
	 * @param WP_Comment $comment Comment to display.
	 * @param int        $depth   Depth of the current comment.
	 * @param array      $args    An array of arguments.
	 */
	protected function html5_comment( $comment, $depth, $args ) {

		$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';

		?>
		<<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( $this->has_children ? 'parent' : '', $comment ); ?>>

			<article id="div-comment-<?php comment_ID(); ?>" class="single_comment mb-40">
				<div class="single_comment">
					<div class="client_cimage">
						<?php
						$comment_author_url = get_comment_author_url( $comment );
						$comment_author     = get_comment_author( $comment );
						$avatar             = get_avatar( $comment, $args['avatar_size'] );
						if ( 0 != $args['avatar_size'] ) {
							if ( empty( $comment_author_url ) ) {
								echo $avatar;
							} else {
								printf( '<a href="%s" rel="external nofollow" class="url">', $comment_author_url );
								echo $avatar;
							}
						}

						/*
						 * Using the `check` icon instead of `check_circle`, since we can't add a
						 * fill color to the inner check shape when in circle form.
						 */
						// if ( twentynineteen_is_comment_by_post_author( $comment ) ) {
						// 	printf( '<span class="post-author-badge" aria-hidden="true">%s</span>', twentynineteen_get_icon_svg( 'check', 24 ) );
						// }
						?>
</div>
						<div class="comment_info">
						
							<?php
						
						printf(
							wp_kses(
								/* translators: %s: Comment author link. */
								__( '%s <span class="screen-reader-text says">says:</span>', 'twentynineteen' ),
								array(
									'span' => array(
										'class' => array(),
									),
								)
							),


							
							'<h6>' . $comment_author . '</h6>'
						);

						if ( ! empty( $comment_author_url ) ) {
							echo '</a>';
						}
						?>
					<!-- .comment-author -->

					<div>
						<?php
						/* translators: 1: Comment date, 2: Comment time. */
						$comment_timestamp = sprintf( __( '%1$s %2$s', 'twentynineteen' ), get_comment_date( 'j M y', $comment ),' // '.get_comment_time() );

						printf(
							'<span datetime="%s" title="%s">%s</span>',
							esc_url( get_comment_link( $comment, $args ) ),
							get_comment_time( '//' ),
							esc_attr( $comment_timestamp ),
							$comment_timestamp
						);

						// $edit_comment_icon = twentynineteen_get_icon_svg( 'edit', 16 );
						// edit_comment_link( __( 'Edit', 'twentynineteen' ), ' <span class="edit-link-sep">&mdash;</span> <span class="edit-link">' . $edit_comment_icon, '</span>' );
						?>
						<p><?php comment_text(); ?></p>
						<?php
						comment_reply_link(
							array_merge(
								$args,
								array(
									'add_below' => 'div-comment',
									'depth'     => $depth,
									'max_depth' => $args['max_depth'],
									'reply_text' => __('Reply <i class="fal fa-chevron-double-right"></i>', 'futexo'),
								)
							)
						);
						?>
									
					</div><!-- .comment-metadata -->
					</div>

					<?php
					$commenter = wp_get_current_commenter();
					if ( $commenter['comment_author_email'] ) {
						$moderation_note = __( 'Your comment is awaiting moderation.', 'twentynineteen' );
					} else {
						$moderation_note = __( 'Your comment is awaiting moderation. This is a preview; your comment will be visible after it has been approved.', 'twentynineteen' );
					}
					?>

					<?php if ( '0' == $comment->comment_approved ) : ?>
					<p class="comment-awaiting-moderation"><?php echo $moderation_note; ?></p>
					<?php endif; ?>

					</div><!-- .comment-meta -->

				

			</article><!-- .comment-body -->


		<?php
	}
}
