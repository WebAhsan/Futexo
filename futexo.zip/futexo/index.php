<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package futexo
 */

get_header();
?>
<main>

<!-- page__title-start -->


<div class="page__title align-items-center" data-background="assets/img/bg/breadcam-bg.jpg">
   <div class="container">
	  <div class="row">
		 <div class="col-xl-12">
			<div class="page__title-content text-center">
			   <h3 class="breadcrumb-title breadcrumb-title-sd mb-15"><?php if (is_page('blog')) {echo 'Blog';}
			   else {echo 'Blog';}?></h3>
			   <div class="page_title__bread-crumb">
			   <nav>
				  <nav class="breadcrumb-trail breadcrumbs">
					 <ul class="breadcrumb-menu">
						<li class="breadcrumb-trail">
						   <a href="<?php echo get_home_url(); ?>"><span>Home</span></a>
						</li>
						<li class="trail-item">
						   <span><?php if (is_page('blog')) {echo 'Blog';}
			  				 else {echo 'Blog';}?></span>
						</li>
					 </ul>
				  </nav> 
			   </nav>
			   </div>
			</div>
		 </div>
	  </div>
   </div>
</div>
<!-- page__title-end -->

<!-- blog_area-start -->
<div class="blog_area pt-120 pb-100">
   <div class="container custome-container">
	  <div class="row">
		 <div class="col-lg-8">
			<div class="main-blog">

			<?php 
				if(have_posts()):
					while(have_posts()):the_post();
			?>
			   <div class="single_mblog mb-50">
				  <div class="mblog_image">
					 <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					 <div class="top_date">
						<span><?php echo get_the_date('j M');?></span>
					 </div>
				  </div>
				  <div class="mblog_info">
					 <div class="mblog__meta mb-15">
						<ul>
						   <li><a href="<?php the_permalink(); ?>"><i class="far fa-bookmark"></i><?php the_category(',');?></a></li>
						   <li><a href="<?php the_permalink();  ?>"><i class="far fa-user"></i><?php the_author(); ?></a></li>
						   <li><a href="<?php the_permalink(); ?>"><i class="fal fa-comments"></i> <?php echo get_comments_number();?></a></li>
						</ul>
					 </div>
					 <h6 class="mblog__title mb-15"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>

					 <?php 
					  ?>
					 <p><?php echo substr(get_the_excerpt(), 0,100);?></p>
					 <div class="mblog-button">
						<a href="<?php the_permalink(); ?>">Continue Reading <i class="fal fa-chevron-double-right"></i></a>
					 </div>
				  </div> 
			   </div>

			<?php 
			endwhile;
				endif; 
					?>

			   <div class="row mt-80">
				  <div class="col-12">
					  <div class="basic-pagination basic-pagination-two mt-10 wow fadeInUp" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
						  <ul>
							  <?php 
							  
							   the_posts_pagination( array(
								'mid_size'  => 2,
								'prev_text' => __( '<i class="fal fa-long-arrow-left"></i>', 'futexo' ),
								'next_text' => __( '<i class="fal fa-long-arrow-right"></i>', 'futexo' ),
							) );
							 
							 ?>
						  </ul>
					  </div>
				  </div>
			   </div>
			</div>
		 </div>
		 <div class="col-lg-4">
			<div class="blog_sidebar">
			
			<?php 
			
			get_sidebar();
			
			?>

			</div>
		 </div>
	  </div>
   </div>
</div>
<!-- blog_area-end -->

</main>


<?php
get_sidebar();
get_footer();
