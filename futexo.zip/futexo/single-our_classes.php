<?php get_header(); ?>

      <main>

         <!-- page__title-start -->
         <div class="page__title align-items-center">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="page__title-content text-center">
                        <h3 class="breadcrumb-title breadcrumb-title-sd mb-15"><?php the_title(); ?></h3>
                        <div class="page_title__bread-crumb">
                        <nav>
                           <nav class="breadcrumb-trail breadcrumbs">
                              <ul class="breadcrumb-menu">
                                 <li class="breadcrumb-trail">
                                    <a href="<?php echo home_url('/');?>"><span>Home</span></a>
                                 </li>
                                 <li class="trail-item">
                                    <span><?php the_title(); ?></span>
                                 </li>
                              </ul>
                           </nav> 
                        </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- page__title-end -->

         <!-- classes_details_area-start -->
         <div class="classes_details_area pt-120 pb-90">
            <div class="container custome-container">
               <div class="row">
                  <div class="col-lg-4">
                     <div class="classes_sidebar mb-30">
                        <div class="classes_widget mb-30">
                           <h5 class="classes_widget_title mb-25"><i class="far fa-circle"></i> Category</h5>
                           <ul class="class_catagory">
                           <?php 
                           $args = array(
                            'taxonomy' => 'classes_category',
                           );
                           $classes_categorys = get_categories($args);
                           foreach($classes_categorys as $classes_category){
                           ?> 
                              <li class="mb-20">
                                 <a href="<?php echo $classes_category->slug;?>"><?php echo $classes_category->name;?></a> 
                                 <a href="<?php echo $classes_category->slug;?>"><i class="fal fa-chevron-double-right"></i></a>
                              </li>
                              <?php };?>
                           </ul>
                        </div>
                        <div class="support-image">
                           <?php $supporter_image = get_field('supporter_image'); ?>
                           <img src="<?php echo $supporter_image['url'];?>" class="img-fluid" alt="support-img">
                        </div>
                        <div class="classes_widget classes_widget_support mb-30">
                           <div class="support_icon">
                              <i class="flaticon-support-1"></i>
                           </div>
                           <h5 class="classes_widget_title mb-25"><i class="far fa-circle"></i> Contact Info</h5>
                           <ul class="support_contact">
                           <?php 
                           $contact_infos = get_field('contact_info');
                           foreach($contact_infos as $contact_info){
                           ?>
                              <li class="d-flex align-items-start pt-5 mb-20">
                                 <div class="support__info-icon mr-20">
                                    <?php echo $contact_info['contact_info_icon']?>
                                 </div>
                                 <div class="support__info-text">
                                    <a target="_blank" href="<?php echo $contact_info['contact_info_text']?>"> <?php echo $contact_info['contact_info_text']?></a>
                                 </div>
                              </li>
                              <?php } ?>
                           </ul>
                        </div>
                        <div class="classes_widget mb-30">
                           <h5 class="classes_widget_title mb-25"><i class="far fa-circle"></i> Download</h5>
                           <ul class="download_option">
                              <li class="d-flex align-items-center mb-20 download_option_list">
                                 <div class="download_icon mr-20">
                                    <a href="#"><i class="fal fa-file-pdf"></i></a>
                                 </div>
                                 <div class="download__info-text ml-20">
                                    <a href="#">Presentation</a>
                                 </div>
                              </li>
                              <li class="d-flex align-items-center download_option_list">
                                 <div class="download_icon mr-20">
                                    <a href="#"><i class="fal fa-file-alt"></i></a>
                                 </div>
                                 <div class="download__info-text ml-20">
                                    <a href="#">Download.txt</a>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-8">
                     <div class="classes_details_info">

                        <div class="class_main_image mb-30">
                           <img src="<?php the_post_thumbnail_url(); ?>" class="img-fluid" alt="class-img">
                        </div>
                        <?php the_content(); 
                        $classes_schedules = get_field('classes_schedule');
                        $related_trainer = get_field('related_trainer');
                         if($related_trainer === 'yes'){
                        ?>
                        <h5 class="classes_detals_title_sm mb-30">Yoga Trainer</h5>
                        <div class="row mb-10">
                        <?php
                           $args = array(
                              'post_type' => 'fitness_trainer',
                              'posts_per_page' => 2,
                           );
                     $trainer_query = new WP_Query($args);
                     if($trainer_query->have_posts()){
                     while($trainer_query->have_posts()):$trainer_query->the_post();
                           
              ?>
             <div class="col-xl-6 col-lg-6 col-md-6">
              <div class="trainer-single wow fadeInUp mb-30" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
                   <div class="trainer-image_cs_details">
                     <a href="team-details.html"><?php the_post_thumbnail(); ?></a>
                   </div>
                   <div class="trainer-info">
                     <h5 class="trainer-name"><a href="<?php the_permalink();?>"><?php the_title();?></a></h5>
                     <p class="mb-20"><?php the_field('trainer_dignation'); ?></p>
                     <?php if(	$show_socail == 'yes'):?>
                     <div class="trainer-soicial-icon">
                     <?php
                     $trainer_socials = get_field('trainer_social');
                     if($trainer_socials ){
                     foreach($trainer_socials as $trainer_social){
                     ?>
                       <a href="<?php echo $trainer_social['social_url'];  ?>"><?php echo $trainer_social['social_icon'];  ?></a>
                     
                       <?php }} ?>
                     </div>

                      <?php endif;?>

                   </div>
                   <div class="trainer-btn">
                     <a href="<?php the_permalink();?>" class="tp-btn-square"><i class="fal fa-chevron-double-right"></i></a>
                   </div>
                </div>
               
              </div>
                <?php endwhile;?>
                   <?php }?>
                     </div>
                      <?php } ?>
                      <h5 class="classes_detals_title_sm mb-30">Class Schedule</h5>
                        <div class="row">
                        <?php 
                        foreach($classes_schedules  as $classes_schedule){
                        ?>
                           <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                           <div class="class_schedule_sm mb-10">
                           <h6><?php echo $classes_schedule['class_day']; ?></h6>
                           <span><?php echo $classes_schedule['class__start']; ?> - <?php echo $classes_schedule['class_end']; ?></span>
                           <p>
                              <?php $trainer_names = $classes_schedule['trainer_name']; 
                              echo $trainer_names->post_title;?>
                           </p>
                           </div>
                        </div>
                        <?php } ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- classes_details_area-end -->
      </main>

      <!-- footer-area-start -->
      <?php get_footer(); ?>
