<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package futexo
 */

?>


      <!-- footer-area-start -->
      <footer>
         <div class="footer-area">
            <div class="footer_top-info">
               <div class="container custome-container">
                  <div class="news-letter-area pt-100 pb-20">
                     <div class="row align-items-center">
                        <div class="col-lg-5">
                           <h5 class="news-letter-title mb-30">Subscribe Newsletter</h5>
                        </div>
                        <div class="col-lg-7">
                          <?php echo do_shortcode('[contact-form-7 id="1122" title="Subscribe Form"]'); ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer-content pt-80 pb-45">
               <div class="container custome-container">
                  <div class="row g-0">
                     <div class="col-lg-4 col-md-8 col-sm-8">
                     <div class="footer-widget fotter-col2 wow fadeInUp mb-40" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                           <?php                        
                                dynamic_sidebar( 'footer-1' );      
                              ?>

                        </div></div>
                     <div class="col-lg-2 col-md-4 col-sm-4">
                        <div class="footer-widget wow fadeInUp mb-40" data-wow-delay=".6s">
                           <h5 class="fotter_widget-title mb-35">Projects</h5>
                           <ul class="fotter_project_lists">
                              <li><a href="protfolio-details.html">February - 2020</a></li>
                              <li><a href="protfolio-details.html">March - 2020</a></li>
                              <li><a href="protfolio-details.html">October - 2020</a></li>
                              <li><a href="protfolio-details.html">November - 2020</a></li>
                              <li><a href="protfolio-details.html">January - 2021</a></li>
                              <li><a href="protfolio-details.html">February - 2021</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-widget wow fadeInUp mb-40" data-wow-delay=".9s">
                        <?php                        
                               dynamic_sidebar( 'footer-3' );      
                              ?>
                           
                        </div>
                     </div> 
                     <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-widget wow fadeInUp mb-40" data-wow-delay="1.3s">
                        <?php                        
                            dynamic_sidebar( 'footer-4' );      
                              ?>
                        </div>
                     </div>
                  </div>


               </div>
            </div>
            <div class="copy-right-area">
               <div class="container custome-container">
                  <div class="copyright-info">
                     <div class="owner_name">
                       <?php echo  get_theme_mod('footer_coopyright_setting');?>
                     </div>
                     <div class="copy-right_useful_link">
                     <?php echo  get_theme_mod('footer_coopyright_link');?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- footer-area-end -->


      <!-- modal-search-start -->
      <div class="modal fade" id="search-modal" tabindex="-1" role="dialog" aria-hidden="true">
         <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
         </button>
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <form>
                     <input type="text" placeholder="Search here...">
                     <button>
                        <i class="fa fa-search"></i>
                     </button>
               </form>
            </div>
         </div>
      </div>
      <!-- modal-search-end -->

	  <?php wp_footer(); ?>
   </body>
</html>
