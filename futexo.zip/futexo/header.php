<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package futexo
 */

?>
	<!doctype html>
<html <?php language_attributes(); ?>>

   <head>
      <meta charset="<?php bloginfo( 'charset' ); ?>">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Place favicon.ico in the root directory -->
      <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
	  <?php wp_head(); ?>
   </head>
   <body <?php body_class(); ?>>
<?php wp_body_open(); ?>
      <!--[if lte IE 9]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
      <![endif]-->

      <!-- Add your site or application content here -->

      <!-- preloader start --
      <div id="preloader">
         <div class="preloader">
            <span></span>
            <span></span>
         </div>
      </div>
       preloader end -->

      <!-- back to top start -->
      <div class="progress-wrap">
         <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
         </svg>
      </div>
      <!-- back to top end -->
      <?php $sticky_bg =  get_theme_mod('header_sticky_clr');?>
      <?php $menu_bg =  get_theme_mod('header_menu_clr');?>
      <?php $menu_color =  get_theme_mod('header_menu_item_clr');?>
      <?php $scroll_position = get_theme_mod('backto_top_btnset');?>
     
      <style>
      .sticky .menu-content{
         background:<?php echo $sticky_bg;?>;
      }
      .sticky{
         background:<?php echo $sticky_bg;?>;
      }
      .menu-content{
         background:<?php echo $menu_bg;?>;
      }
      .main-menu ul li a{
         color:<?php echo $menu_color;?>;
      }
      .progress-wrap{
         left:<?php echo $scroll_position;?>%;
      }
      </style>
      <!-- top-nav-start -->
      <header class="top-nav">
         <div class="top-address d-none d-lg-block">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-xxl-7 col-xl-5 col-lg-4 col-md-3">
                     <div class="top-logo">
                        <a href="#">
                           <?php 
                              $custom_logo_id = get_theme_mod( 'custom_logo' );
                              $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                              
                              if ( has_custom_logo() ) {
                                 echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
                              } else {
                                 echo '<h1>' . get_bloginfo('name') . '</h1>';
                              }
						      ?>
                  </a>
                     </div>
                  </div>
                  <div class="col-xxl-5 col-xl-7 col-lg-8 col-md-9">
                     <?php 
                     
                     $header_switcher = get_theme_mod('header_position_btnset');
                     if( $header_switcher == true){
                     ?>
                     <div class="topbar-info">

                        <?php
                        
                        $contact_items = get_theme_mod('header_top_repeater');
                        if($contact_items){
                        foreach($contact_items as $contact_item){
                         
                        ?>
                        <div class="contact-item">
                           <i class="<?php echo $contact_item['contact_item_icon'];?>"></i>
                           <div class="content">
                              <p><?php echo $contact_item['contact_item_title'];?></p>
                              <a href="<?php echo $contact_item['contact_item_des'];?>" target="blank"><?php echo $contact_item['contact_item_des'];?></a>
                           </div>
                        </div>
                        <?php }}?>


                     </div>
                     <?php } ?>
                  </div>
               </div>
            </div>
         </div>
         <div class="menu-area" id="<?php echo get_theme_mod('header_position_btnset');?>">
            <div class="<?php echo get_theme_mod('header_width_btnset');?>">
               <div class="row align-items-center justify-content-center">
                  <div class="col-xxl-12 col-xl-12 col-lg-12">
                  
                     <?php 
                     $btn_switcher =  get_theme_mod('header_btn_switcher');
                     if($btn_switcher == true){
                     
                     ?>
                     <div class="topcontact-btn f-right d-none d-lg-block">
                        <div class="contact-btn">
                           <a href="<?php echo get_theme_mod('header_contact_link');?>" class="top-btn"><?php echo get_theme_mod('header_contact_text');?> <i class="fal fa-chevron-double-right"></i></a>
                        </div>
                     </div>
                     <?php }?>
                     <div class="menu-content">
                        <div class="top-logo d-lg-none">
                           <a href="index.html">
                              <?php 
                              $custom_logo_id = get_theme_mod( 'custom_logo' );
                              $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                              
                              if ( has_custom_logo() ) {
                                 echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
                              } else {
                                 echo '<h1>' . get_bloginfo('name') . '</h1>';
                              }
						?></a>
                        </div>
                        <div class="main-menu">
							  <?php 
							  
							  wp_nav_menu( array(
								'menu'           => 'Project Nav', // Do not fall back to first non-empty menu.
								'theme_location' => 'main-menu',
								'menu_id'        => 'mobile-menu',
								'container'      => 'nav',
								
							) );
							 
							 ?>
                        </div>
                        <div class="side-menu-icon d-lg-none text-end">
                           <a href="javascript:void(0)" class="info-toggle-btn f-right sidebar-toggle-btn"><i class="fal fa-bars"></i></a>
                        </div>
                        <div class="header-action-btn f-right d-none d-lg-block">
                           <a href="javascript:void(0)" data-bs-toggle="modal" class="search" data-bs-target="#search-modal"><i class="far fa-search"></i></a>
                  
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- top-nav-end -->

      <!-- sidebar area start -->
      <div class="sidebar__area">
         <div class="sidebar__wrapper">
            <div class="sidebar__close">
               <button class="sidebar__close-btn" id="sidebar__close-btn">
                  <i class="fal fa-times"></i>
               </button>
            </div>
            <div class="sidebar__content">

 
               <div class="sidebar__logo mb-40">
                  <a href="<?php echo home_url('/');?>">
                  <?php 
					 	$custom_logo_id = get_theme_mod( 'custom_logo' );
						 $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
						  
						 if ( has_custom_logo() ) {
							 echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
						 } else {
							 echo '<h1>' . get_bloginfo('name') . '</h1>';
						 }
						?>
                  </a>
               </div>
               <div class="sidebar__search mb-25">
                  <form action="/" method="get">
                     <input type="text" value="<?php the_search_query(); ?>" name="s" id="s"  placeholder="What are you searching for?">
                     <button type="submit"  value="' . esc_attr_x( 'Search', 'submit button' ) . '" ><i class="far fa-search"></i></button>
                  </form>
               </div>
               <div class="mobile-menu fix"></div>
               <?php echo dynamic_sidebar('top-sidebar');?>
            </div>
         </div>
      </div>
      <!-- sidebar area end -->      
      <div class="body-overlay"></div>
      <!-- sidebar area end -->