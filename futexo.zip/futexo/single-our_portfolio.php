<?php get_header();?>

      <!-- body-overlay -->

      <main>

         <!-- page__title-start -->
         <div class="page__title align-items-center">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="page__title-content text-center">
                        <h3 class="breadcrumb-title breadcrumb-title-sd mb-15"><?php the_title(); ?></h3>
                        <div class="page_title__bread-crumb">
                        <nav>
                           <nav class="breadcrumb-trail breadcrumbs">
                              <ul class="breadcrumb-menu">
                                 <li class="breadcrumb-trail">
                                    <a href="<?php echo home_url('/');?>"><span>Home</span></a>
                                 </li>
                                 <li class="trail-item">
                                    <span><?php the_title(); ?></span>
                                 </li>
                              </ul>
                           </nav> 
                        </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- page__title-end -->

         <!-- portfolio_details_area-start -->
         <div class="portfolio_details_area pt-110 pb-90">
            <div class="container custome-container">
               <h5 class="pt_details_title mb-30"><?php the_title(); ?></h5>
               <p class="mb-30"><?php the_excerpt();?></p>
               <div class="portfolio_details-img mb-35">
                  <img src="<?php the_post_thumbnail_url(); ?>" alt="details img">
               </div>
               <div class="row">
                  <div class="col-lg-8">
                     <div class="mb-35">
                        <?php the_content();?>
                     </div>
                     <h6 class="pd_sm_title mb-25">Client Feedback</h6>
                     <div class="mb-110">
                        <div class="swiper-container client-feedback_active">
                           <div class="swiper-wrapper">
                           <?php 
                                 $cusomer_infos = get_field('customer_info'); 
                                  $feedbacks = $cusomer_infos['client_feedback'];
                                  if( $feedbacks){
                                  foreach($feedbacks as $feedback){
                                    $client_img = $feedback['client_image']['url'];
                                    $client_review = $feedback['client_review_'];
                                 
                                 ?>
                              <div class="swiper-slide ">


                                 <div class="client-feedback">
                                    <div class="client-image mr-40">
                                       <?php ?>
                                       <img src="<?php echo $client_img; ?>" alt="client">
                                       <div class="quote-icon">
                                          <i class="fas fa-quote-left"></i>
                                       </div>
                                    </div>
                                    <div class="client-review pdclient-review">
                                       <p><?php echo $client_review; ?></p>
                                    </div>
                                 </div>
                      


                              </div>
                              <?php }} ?>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="portfolio_sidebar mb-30">
                        <div class="sidebar_meta">
                           <?php $cusomer_info = get_field('customer_info'); ?>
                           <h6 class="pd_sidebar_title_top">Customer Info</h6>
                        </div>
                        <div class="sidebar_content">
                        <ul>  
                             <?php if( $cusomer_info['add_service_name']){?>
                              <li class="sidebar_list mb-20">
                                 <p><?php echo $cusomer_info['add_service_name']; ?></p>
                                 <h6 class="pd_sidebar_title mb-30">Service Name</h6>
                              </li>
                              <?php }?>
                              <?php if( $cusomer_info['add_category']){?>
                              <li class="sidebar_list mb-20">
                                 <p><?php echo $cusomer_info['add_category']; ?></p>
                                 <h6 class="pd_sidebar_title mb-30">Categories</h6>
                              </li>
                              <?php }?>
                              <?php if( $cusomer_info['add_client_name']){?>
                              <li class="sidebar_list mb-20">
                                 <p><?php echo $cusomer_info['add_client_name'];?></p>
                                 <h6 class="pd_sidebar_title mb-30">Client Name</h6>
                              </li>
                              <?php }?>
                              <?php if( $cusomer_info['add_date']){?>
                              <li class="sidebar_list mb-20">
                                 <p><?php echo $cusomer_info['add_date']; ?></p>
                                 <h6 class="pd_sidebar_title mb-30">Service Date</h6>
                              </li>
                              <?php }?>
                              <?php if( $cusomer_info['add_feedback']){?>
                              <li class="sidebar_list">
                                 <p><?php echo $cusomer_info['add_feedback']; ?></p>
                                 <h6 class="pd_sidebar_title pd_sidebar_title_last">Client Feedback</h6>
                              </li>
                              <?php }?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <?php
               
               $related_portfolio = get_field('related_portfolio');
               if($related_portfolio == 'yes'){
               
               ?>
               <h5 class="pt_details_title mb-30">Related Portfolio</h5>
               <div class="row">
                  <?php 

                  $portfolios = array(
                     'post_type' => 'our_portfolio',
                  );
                  $portfolio_query = new WP_Query($portfolios);
                  while($portfolio_query->have_posts()): $portfolio_query->the_post();
                  ?>
                        <div class="col-lg-6 <?php
                     $get_cats = get_the_terms(get_the_ID(),'portfolio_category');
                     foreach($get_cats as $get_cat){
                     echo $get_cat->slug.' ' ;
                     }
                     ?>">
                           <div class="single_portfolio_item mb-30">
                              <div class="portfolio_image">
                                 <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                              </div>
                              <div class="portfolio-info">
                                 <div class="portfolio-content">
                                    <span><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
                                    <p>Weight loss Program</p>
                                 </div>
                                 <div class="portfolio_d-icon">
                                    <a href="<?php the_permalink(); ?>" class="tp-btn-circle"><i class="fal fa-chevron-double-right"></i></a>
                                 </div>
                              </div>
                           </div>
                        </div>
                  <?php endwhile;?>

               </div>

               <?php } ?>
            </div>
         </div>
         <!-- portfolio_details_area-end -->
      </main>

      <!-- footer-area-start -->
<?php get_footer();?>