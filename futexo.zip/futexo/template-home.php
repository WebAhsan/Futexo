<?php
/**
* Template Name: Home Page
*
* @package WordPress
* @subpackage Futexo
* @since Futexo 1.0
*/
?>
<?php get_header(); ?> 
      <main>
      <?php the_content();?>
      </main>

      <!-- footer-area-start -->
<?php get_footer(); ?>