<?php get_header(); ?>

      <!-- body-overlay end -->

      <main>

         <!-- page__title-start -->
         <div class="page__title align-items-center" data-background="<?php the_post_thumbnail_url(); ?>">
            <div class="container">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="page__title-content text-center">
                        <h3 class="breadcrumb-title breadcrumb-title-sd mb-15"><?php the_title();?></h3>
                        <div class="page_title__bread-crumb">
                        <nav>
                           <nav class="breadcrumb-trail breadcrumbs">
                              <ul class="breadcrumb-menu">
                                 <li class="breadcrumb-trail">
                                    <a href="<?php echo home_url('/') ?>"><span>Home</span></a>
                                 </li>
                                 <li class="trail-item">
                                    <span><?php the_title();?></span>
                                 </li>
                              </ul>
                           </nav> 
                        </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- page__title-end -->

         <!-- blog_area-start -->
         <div class="blog_area pt-120 pb-70">
            <div class="container custome-container">
               <div class="row">
                  <div class="col-lg-8 col-md-8">
                     <div class="main-blog">
                        <div class="single_mblog mb-50">
                           <div class="mblog_image mb-30">
                              <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                              <div class="top_date">
                                 <span><?php echo get_the_date('j M'); ?></span>
                              </div>
                           </div>
                           <div class="mblog_info mblog_details">
                              <div class="mblog__meta mb-15">
                                 <ul>
                                    <li><a href="<?php the_permalink(); ?>"><i class="far fa-bookmark"></i> <?php the_category(','); ?></a></li>
                                    <li><a href="<?php the_permalink(); ?>"><i class="far fa-user"></i> <?php the_author(); ?></a></li>
                                    <li><a href="<?php the_permalink(); ?>"><i class="fal fa-comments"></i><?php echo get_comments_number();?> </a></li>
                                 </ul>
                              </div>
                              <h6 class="mblog__title mb-15"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                              <?php the_content();?>
                     </div>
                     <div class="blog_nav mb-50">
                        <div class="blog-action-wrapper">
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="blog_dmeta mb-20">
                                    <p><i class="far fa-bookmark"></i><?php the_tags(',');?></p>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="blog_dmeta mb-20 text-sm-end">
                                    <div class="share-social_icon">
                                       <a href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink();?>"><i class="fab fa-facebook-f"></i></a>
                                       <a href="https://twitter.com/intent/tweet/?url=<php get_url(); ?>"><i class="fab fa-twitter"></i></a>
                                       <a href="https://www.linkedin.com/cws/share?url=<?php echo  the_permalink() ;?>"><i class="fab fa-linkedin-in"></i></a>
                                       <a href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class="fab fa-google-plus-g"></i></a>
                                    </div>
                                 </div>
   
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-6">
							   <div class="blog_moption mb-20">
							   <?php
									$prev_post = get_previous_post(); 
									$id = $prev_post->ID ;
									$permalink = get_permalink( $id );
								?>
							<a href="<?php echo $permalink; ?>" class="mb-10"><?php previous_post_link( '%link', __( 'Previous Post', 'twentyeleven' ) ); ?></a>
                                 <h6><a href="<?php echo $permalink; ?>"><?php echo $prev_post->post_title; ?></a></h6>





                              </div>
                           </div>
                           <div class="col-md-6">
						   <?php 
								$next_post = get_next_post();
								$nid = $next_post->ID ;
								$permalink = get_permalink($nid);
							?>
						   <div class="blog_moption mb-20 text-sm-end">
                                 <a href="<?php echo $permalink; ?>" class="mb-10"><?php next_post_link( '%link', __( 'Next Post', 'twentyeleven' ) ); ?></a>
                                 <h6><a href="<?php echo $permalink; ?>"><?php echo $next_post->post_title; ?></a></h6>
                              <div></div></div>

                           </div>
                        </div>
                     </div>

                     <?php 
                     $texts = get_post_meta( get_the_ID(), 'futexo_related_post', true );
                     if( $texts  == 'on'):
                        ?>
                     <h6 class="mblog_dtitle mb-20">Related Article</h6>
                     <div class="row mb-30">
                     <?php 
                     $categories = get_the_category();
                     $date = get_the_date();
                     $type = get_post_meta( get_the_ID(), 'futexo_related_post_type', true );
                     if( $type  == 'Category'):
                     $args = array(
                        'post_type' => 'post',
                        'orderby' => $categories,
                        'posts_per_page' => 2,
                     );
                     $related_post_query = new WP_Query( $args);
                     while( $related_post_query->have_posts()) :  $related_post_query->the_post();
                     ?>
                        <div class="col-md-6">
                           <div class="sidebar_post mb-30">
                              <div class="post-image mb-20">
                                 <a href="blog-details.html"><?php the_post_thumbnail(); ?></a>
                              </div>
                              <span class="small-post_date mb-10"><?php echo get_the_date('j F - Y'); ?></span>
                              <h6 class="small-post_title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h6>
                           </div>
                        </div>
                        <?php endwhile; endif;
                     if( $type  == 'Date'):
                     $args = array(
                        'post_type' => 'post',
                        'orderby' => $date,
                        'posts_per_page' => 2,
                     );
                     $related_post_query = new WP_Query( $args);
                     while( $related_post_query->have_posts()) :  $related_post_query->the_post();
                     ?>
                        <div class="col-md-6">
                           <div class="sidebar_post mb-30">
                              <div class="post-image mb-20">
                                 <a href="blog-details.html"><?php the_post_thumbnail(); ?></a>
                              </div>
                              <span class="small-post_date mb-10"><?php echo get_the_date('j F - Y'); ?></span>
                              <h6 class="small-post_title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h6>
                           </div>
                        </div>
                        <?php endwhile; endif; ?>
                     </div>
                 <?php  endif; ?>

                 <?php
                  if(comments_open()){
                     comments_template();
                  }
                 ?>

                  </div>

               </div>
            </div>
			
			                  <div class="col-lg-4 col-md-4">
				  <div class="blog_sidebar">

			
<?php 

if ( is_active_sidebar( 'sidebar' ) ){
	dynamic_sidebar('sidebar');
}else{
	echo '<h2>Add Widget In Sidebar </h2>';
}

?>
</div>
</div>

         </div>
		 </div>
</div>
         <!-- blog_area-end -->
        
      </main>

<?php get_footer(); ?>
