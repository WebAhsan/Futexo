<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package futexo
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) :
		?>
		<h6 class="mblog_dtitle mb-25">
			<?php
			$futexo_comment_count = get_comments_number();
			if ( '1' === $futexo_comment_count ) {
				printf(
					/* translators: 1: title. */
					esc_html__( 'Comment', 'futexo' ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			} else {
				printf( 
					/* translators: 1: comment count number, 2: title. */
					esc_html( _nx( ' Comments [%1$s]', ' Comments [%1$s] ', $futexo_comment_count, 'comments title', 'futexo' ) ),
					number_format_i18n( $futexo_comment_count ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			}
			?>
		</h6><!-- .comments-title -->

		<?php the_comments_navigation(); ?>

		<div class="client_commenta mb-10">
			<?php
			wp_list_comments(
				array(
					'walker'      => new futexo_Walker_Comment(),
					'style'      => 'ol',
					'short_ping' => true,
					'avatar_size' => '100',
				)
			);
			?>
		</div><!-- .comment-list -->

		<?php
		the_comments_navigation();

		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'futexo' ); ?></p>
			<?php
		endif;

	endif; // Check for have_comments().


 


	
 

	$fields = array(
        'author' => sprintf(
            '<div class="col-md-6"><div class="tp-support-form-field tp-support-form-field-two mb-20">%s %s</div> </div>',
            sprintf(
                
                ( $req ? $required_indicator : '' )
            ),
            sprintf(
                '<input id="author" placeholder="Full name" name="author" type="text" size="30" />',
                esc_attr( $commenter['comment_author'] ),
                ( $req ? $required_attribute : '' )
            )
        ),
        'email'  => sprintf(
            '<div class="col-md-6"><div class="tp-support-form-field tp-support-form-field-two mb-20">%s %s</div></div>',
            sprintf(
                ( $req ? $required_indicator : '' )
            ),
            sprintf(
                '<input id="email" name="email" %s  size="30" placeholder="Email Address" aria-describedby="email-notes"%s />',
                ( $html5 ? 'type="email"' : 'type="text"' ),
                esc_attr( $commenter['comment_author_email'] ),
                ( $req ? $required_attribute : '' )
            )
        ),
    );

	$fields = apply_filters( 'comment_form_default_fields', $fields );

	$defaults = array(

       
        'comment_field'        => sprintf(
            '<div class="tp-support-form-field mb-20">%s %s</div>',
            sprintf(
                $required_indicator
            ),
            '<textarea id="comment" name="comment" cols="45" placeholder="Your Message" rows="8" maxlength="65525"' . $required_attribute . '></textarea>',
			
        ),
		'fields'               => $fields,
		'label_submit'         => __( 'Send Message &#xf1d8;' ),
		'class_form'           => 'row',
		'class_submit'         => 'tp-btn-round',
		'submit_field'         => '<div class="support-btn mb-30">%1$s %2$s</div>',
	

	);


	comment_form($defaults);
	?>

</div><!-- #comments -->
