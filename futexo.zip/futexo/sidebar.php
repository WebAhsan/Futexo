<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package futexo
 */


if ( is_active_sidebar( 'sidebar' ) ){
	dynamic_sidebar('sidebar');
}else{
	echo '<h2>Add Widget In Sidebar </h2>';
}
